package model;

import java.util.ArrayList;

public class Customer {

    private String firstname;
    private ArrayList<String> burger;
    private ArrayList<String> customization;
    private String size;


    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public ArrayList<String> getBurger() {
        return burger;
    }

    public void setBurger(ArrayList<String> burger) {
        this.burger = burger;
    }

    public ArrayList<String> getCustomization() {
        return customization;
    }

    public void setCustomization(ArrayList<String> customization) {
        this.customization = customization;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "firstname='" + firstname + '\'' +
                ", burger=" + burger +
                ", customization=" + customization +
                ", size='" + size + '\'' +
                '}';
    }

}
