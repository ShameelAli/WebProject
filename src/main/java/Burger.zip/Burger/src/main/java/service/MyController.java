package service;

import model.Customer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;

@Controller

public class MyController {


    @RequestMapping(value = "/check.com" ,method = RequestMethod.GET)
    public String Login(Model model)
    {

        Customer customer=new Customer();
        model.addAttribute("user",customer);

        return "burgerpoint";
    }

@RequestMapping(value="/check.com",method = RequestMethod.POST)

       public String check(HttpServletRequest request,@Valid @ModelAttribute("customer") Customer customer,Model model)

        {
            String firstname=request.getParameter("firstname");
            String burgers[] =request.getParameterValues("burger");

            ArrayList<String> choice=new ArrayList<>();

            String customization[]=request.getParameterValues("customization");

            String size=request.getParameter("size");

            for(int i=0;i<burgers.length;i++)
            {
                choice.add(burgers[i]);
            }


            ArrayList<String> topping=new ArrayList<>();
            for(int i=0;i<customization.length;i++)
            {
                topping.add(customization[i]);
            }


            Customer customer1=new Customer();

            model.addAttribute("Buyer Name",firstname);
            model.addAttribute("Burger Chosen",burgers);
            model.addAttribute("Topping Customization",topping);
            model.addAttribute("Size",size);


            customer1.setFirstname(firstname);
            customer1.setSize(size);

        return "bill";
        }





    @RequestMapping({"/recheck.do"})
    public String Recheck() {
        return "Hellorecheck";
    }

}
